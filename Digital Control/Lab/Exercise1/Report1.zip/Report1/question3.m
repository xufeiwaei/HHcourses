%question3a
Ba = [0 0.1 -0.2];
Aa = [1 -0.1 0];
figure,zplane(Ba,Aa);
%question3b
Bb = [0 0.1];
Ab = [1 -0.9];
figure,zplane(Bb,Ab);
%question3c
Bc = [-10 +3 -0.2];
Ac = [1 -1.7 0.72];
figure,zplane(Bc,Ac);
%question3d
Bd = [0 0 0 0 0 0 0 0 0 0 2];
Ad = [1 -2 0 0 0 0 0 0 0 0 0];
figure,zplane(Bd,Ad);